CD AI Indicator Analysis — Crypto BTC/ETH
- Upload index.html to the root of your GitHub repository.
- GitHub repository > Settings > Pages > Deploy from a branch > main > /(root) > Save.
- Wait for the Pages URL and open it.

Includes public Binance candle fetch, candle chart, EMA 9/20/50/200, RSI, volume ratio, ATR-based illustrative levels, rule-agreement score, and a simplified historical EMA crossover simulation.
Not connected: AI model, news feed, macro feed, Telegram alerts, order execution.
No win-rate guarantee. Backtest omits fees, slippage, funding and realistic order execution. Use paper trading first.
Never place Telegram bot tokens in frontend code. Revoke any token previously exposed and create a replacement.
