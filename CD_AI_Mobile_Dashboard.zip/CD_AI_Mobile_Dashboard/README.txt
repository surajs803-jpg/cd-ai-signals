CD AI mobile dashboard starter
1. Extract ZIP.
2. Upload index.html to your GitHub repository.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch, branch main, folder /(root), Save.
5. Wait for GitHub Pages URL.
This is a UI prototype. Binance public data may be blocked by browser/network/CORS. Telegram alerts, news/macro feeds and a robust backtest are not implemented. Do not put secrets/tokens in the HTML. The previously shared Telegram token should be revoked and replaced.
